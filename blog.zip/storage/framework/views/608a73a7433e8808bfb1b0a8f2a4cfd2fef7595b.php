 

 
 <?php $__env->startSection('title', 'Page Title'); ?>
  
 <?php $__env->startSection('sidebar'); ?>
     @parent
  
     <p>This is appended to the master sidebar.</p>
 <?php $__env->stopSection(); ?>
  
 <?php $__env->startSection('content'); ?>
     <p>This is my body content.</p>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lymen\Desktop\laravel\blog\resources\views/header.blade.php ENDPATH**/ ?>
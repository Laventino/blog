<div class="nav-main">
    Nav
</div><?php /**PATH C:\Users\lymen\Desktop\laravel\blog\resources\views/navbar.blade.php ENDPATH**/ ?>
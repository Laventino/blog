<?php $__env->startSection('content'); ?>
    <style>
        .login-page {
            width: 100%;
            height: 100vh;
        }

        .login-page .container {
            /* background-color: #f7faff; */
            background-image: repeating-linear-gradient(#f7faff 0%, #ecf0f8 45%, #f2f7ff 100%);
            height: 100%;
        }

        .login-page .card-wrapper {
            position: absolute;
            top: 300px;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .login-page .card {
            max-width: 380px;
            min-width: 380px;
            padding: 34px 42px 20px 42px;
            background-color: #fdfdfd;
            border-radius: 3px;
            box-shadow: 0 0 8px 4px #dfe1e9;
        }

        .login-page .logo-container {
            width: 100%;
            height: 100px;
            display: flex;
            justify-content: center;
            margin: 0 0 46px 0;

        }

        .login-page input[type='password'],
        .login-page input[type='email'] {
            height: 36px;
            border: none;
            border-radius: 3px;
            padding: 0 12px;
            font-size: 14px;
            margin: 0 0 18px 0;
            width: 100%;
            outline: #dfdfdf solid 2px;

        }

        .login-page input[type='password']:focus-visible,
        .login-page input[type='email']:focus-visible {
            border: none;
            outline: none;
            outline: #6287A2 solid 2px;

        }

        .login-page .fgp-container {
            display: flex;
            justify-content: end;
        }

        .login-page .fgp-container a {
            color: grey;
            text-decoration: none;
            font-size: 14px;
        }

        .login-page .fgp-container a:hover {
            color: rgb(63, 120, 177);
        }

        .login-page .btn-submit {
            font-size: 16px;
            background-color: #6287A2;
            cursor: pointer;
            border: none;
            width: 100%;
            color: white;
            height: 36px;
            border-radius: 3px;
            margin: 0 0 46px 0;
        }

        .login-page .btn-submit:hover {
            background-color: #486e8b;
        }

        .login-page .sigin-banner {
            display: flex;
            justify-content: center;
            margin-bottom: 24px;
            font-weight: bold;
            color: #888888;
        }
    </style>
    <div class="login-page">
        <div class="container">
            <div class="card-wrapper">
                <div class="logo-container"><img src="<?php echo e(URL::to('/')); ?>/assets/image/logo.svg" width="100%" height="100%"
                        alt=""></div>
                <div class="card">
                    <div class="sigin-banner">
                        Sign In
                    </div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="">

                                <div class="">
                                    <input id="email" type="email" class=" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="email" placeholder="<?php echo e(__('E-Mail Address')); ?>" value="<?php echo e(old('email')); ?>"
                                        required autocomplete="email" autofocus>

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-6">
                                    <input id="password" type="password" placeholder="<?php echo e(__('Password')); ?>"
                                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                        required autocomplete="current-password">

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-6 offset-md-4">
                                    <div class="form-check">
                                        <label class="normal-checkbox" for="remember"><?php echo e(__('Remember Me')); ?>

                                            <input type="checkbox" name="remember" id="remember"
                                                <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn-submit">
                                <?php echo e(__('Login')); ?>

                            </button>


                            <div class="fgp-container">
                                <div class="">

                                    <?php if(Route::has('password.request')): ?>
                                        <a class="" href="<?php echo e(route('password.request')); ?>">
                                            <?php echo e(__('Forgot Your Password?')); ?>

                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lymen\Documents\GitHub\blog\resources\views/auth/login.blade.php ENDPATH**/ ?>
<div class="nav-main">
    Nav
</div><?php /**PATH C:\Users\lymen\Documents\GitHub\blog\resources\views/dashboard/navbar.blade.php ENDPATH**/ ?>